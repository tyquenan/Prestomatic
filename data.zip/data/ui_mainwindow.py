# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainwindow.ui'
##
## Created by: Qt User Interface Compiler version 6.7.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QDoubleSpinBox, QFormLayout,
    QFrame, QGridLayout, QLabel, QLayout,
    QLineEdit, QMainWindow, QProgressBar, QPushButton,
    QRadioButton, QScrollArea, QSizePolicy, QSpinBox,
    QTabWidget, QTextBrowser, QVBoxLayout, QWidget)

from classes import AnimatedToggle
from pyqtgraph import PlotWidget

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(812, 500)
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(MainWindow.sizePolicy().hasHeightForWidth())
        MainWindow.setSizePolicy(sizePolicy)
        MainWindow.setAutoFillBackground(True)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.gridLayout = QGridLayout(self.centralwidget)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setHorizontalSpacing(6)
        self.gridLayout.setContentsMargins(4, 4, 4, 4)
        self.tabWidget = QTabWidget(self.centralwidget)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setCursor(QCursor(Qt.ArrowCursor))
        self.tab = QWidget()
        self.tab.setObjectName(u"tab")
        self.tab.setCursor(QCursor(Qt.ArrowCursor))
        self.gridLayout_3 = QGridLayout(self.tab)
        self.gridLayout_3.setObjectName(u"gridLayout_3")
        self.frame = QFrame(self.tab)
        self.frame.setObjectName(u"frame")
        self.frame.setFrameShape(QFrame.Box)
        self.frame.setFrameShadow(QFrame.Raised)
        self.verticalLayout = QVBoxLayout(self.frame)
        self.verticalLayout.setSpacing(9)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(6, 6, 6, 6)
        self.Plotter_2 = PlotWidget(self.frame)
        self.Plotter_2.setObjectName(u"Plotter_2")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.MinimumExpanding)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.Plotter_2.sizePolicy().hasHeightForWidth())
        self.Plotter_2.setSizePolicy(sizePolicy1)
        self.Plotter_2.setMinimumSize(QSize(0, 0))
        self.Plotter_2.setAutoFillBackground(False)

        self.verticalLayout.addWidget(self.Plotter_2)

        self.Plotter = PlotWidget(self.frame)
        self.Plotter.setObjectName(u"Plotter")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.MinimumExpanding)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.Plotter.sizePolicy().hasHeightForWidth())
        self.Plotter.setSizePolicy(sizePolicy2)
        self.Plotter.setAutoFillBackground(False)

        self.verticalLayout.addWidget(self.Plotter)


        self.gridLayout_3.addWidget(self.frame, 0, 10, 18, 1)

        self.label_9 = QLabel(self.tab)
        self.label_9.setObjectName(u"label_9")

        self.gridLayout_3.addWidget(self.label_9, 1, 2, 1, 1, Qt.AlignRight)

        self.pushButton = QPushButton(self.tab)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setCursor(QCursor(Qt.PointingHandCursor))
        icon = QIcon()
        icon.addFile(u"recorder.png", QSize(), QIcon.Normal, QIcon.Off)
        self.pushButton.setIcon(icon)
        self.pushButton.setCheckable(True)
        self.pushButton.setChecked(False)

        self.gridLayout_3.addWidget(self.pushButton, 2, 3, 1, 2)

        self.label_6 = QLabel(self.tab)
        self.label_6.setObjectName(u"label_6")

        self.gridLayout_3.addWidget(self.label_6, 1, 4, 1, 1)

        self.radioButton_2 = QRadioButton(self.tab)
        self.radioButton_2.setObjectName(u"radioButton_2")
        self.radioButton_2.setCursor(QCursor(Qt.PointingHandCursor))

        self.gridLayout_3.addWidget(self.radioButton_2, 2, 2, 1, 1)

        self.Add = QPushButton(self.tab)
        self.Add.setObjectName(u"Add")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(1)
        sizePolicy3.setHeightForWidth(self.Add.sizePolicy().hasHeightForWidth())
        self.Add.setSizePolicy(sizePolicy3)
        self.Add.setMinimumSize(QSize(90, 25))
        self.Add.setCursor(QCursor(Qt.PointingHandCursor))
        self.Add.setAutoDefault(False)
        self.Add.setFlat(False)

        self.gridLayout_3.addWidget(self.Add, 3, 2, 1, 1)

        self.fold = QPushButton(self.tab)
        self.fold.setObjectName(u"fold")
        self.fold.setCursor(QCursor(Qt.PointingHandCursor))
        icon1 = QIcon()
        icon1.addFile(u"folder.png", QSize(), QIcon.Normal, QIcon.Off)
        self.fold.setIcon(icon1)

        self.gridLayout_3.addWidget(self.fold, 17, 3, 1, 1, Qt.AlignLeft)

        self.doubleSpinBox_2 = QDoubleSpinBox(self.tab)
        self.doubleSpinBox_2.setObjectName(u"doubleSpinBox_2")
        self.doubleSpinBox_2.setCursor(QCursor(Qt.PointingHandCursor))
        self.doubleSpinBox_2.setMaximum(50.000000000000000)

        self.gridLayout_3.addWidget(self.doubleSpinBox_2, 0, 3, 1, 2)

        self.radioButton = QRadioButton(self.tab)
        self.radioButton.setObjectName(u"radioButton")
        self.radioButton.setCursor(QCursor(Qt.PointingHandCursor))

        self.gridLayout_3.addWidget(self.radioButton, 0, 2, 1, 1)

        self.pushButton_4 = QPushButton(self.tab)
        self.pushButton_4.setObjectName(u"pushButton_4")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Fixed)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.pushButton_4.sizePolicy().hasHeightForWidth())
        self.pushButton_4.setSizePolicy(sizePolicy4)
        self.pushButton_4.setCursor(QCursor(Qt.PointingHandCursor))
        icon2 = QIcon()
        icon2.addFile(u"save.png", QSize(), QIcon.Normal, QIcon.Off)
        self.pushButton_4.setIcon(icon2)

        self.gridLayout_3.addWidget(self.pushButton_4, 17, 2, 1, 1, Qt.AlignRight)

        self.checkBox = AnimatedToggle(self.tab)
        self.checkBox.setObjectName(u"checkBox")
        self.checkBox.setMaximumSize(QSize(70, 16777215))
        self.checkBox.setCursor(QCursor(Qt.PointingHandCursor))

        self.gridLayout_3.addWidget(self.checkBox, 1, 5, 1, 1, Qt.AlignLeft)

        self.progressBar = QProgressBar(self.tab)
        self.progressBar.setObjectName(u"progressBar")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        sizePolicy5.setHorizontalStretch(0)
        sizePolicy5.setVerticalStretch(0)
        sizePolicy5.setHeightForWidth(self.progressBar.sizePolicy().hasHeightForWidth())
        self.progressBar.setSizePolicy(sizePolicy5)
        self.progressBar.setMaximumSize(QSize(16777215, 15))
        self.progressBar.setStyleSheet(u"gridline-color: rgb(0, 0, 255);")
        self.progressBar.setValue(0)
        self.progressBar.setTextVisible(True)
        self.progressBar.setInvertedAppearance(False)

        self.gridLayout_3.addWidget(self.progressBar, 16, 2, 1, 6)

        self.pushButton_2 = QPushButton(self.tab)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setCursor(QCursor(Qt.PointingHandCursor))
        self.pushButton_2.setCheckable(False)

        self.gridLayout_3.addWidget(self.pushButton_2, 0, 5, 1, 1)

        self.pattern = QPushButton(self.tab)
        self.pattern.setObjectName(u"pattern")
        self.pattern.setCursor(QCursor(Qt.PointingHandCursor))

        self.gridLayout_3.addWidget(self.pattern, 4, 3, 1, 2)

        self.checkBox_2 = AnimatedToggle(self.tab)
        self.checkBox_2.setObjectName(u"checkBox_2")
        self.checkBox_2.setCursor(QCursor(Qt.PointingHandCursor))

        self.gridLayout_3.addWidget(self.checkBox_2, 1, 3, 1, 1, Qt.AlignLeft)

        self.lineEdit = QLineEdit(self.tab)
        self.lineEdit.setObjectName(u"lineEdit")
        sizePolicy6 = QSizePolicy(QSizePolicy.Policy.MinimumExpanding, QSizePolicy.Policy.Fixed)
        sizePolicy6.setHorizontalStretch(0)
        sizePolicy6.setVerticalStretch(0)
        sizePolicy6.setHeightForWidth(self.lineEdit.sizePolicy().hasHeightForWidth())
        self.lineEdit.setSizePolicy(sizePolicy6)
        self.lineEdit.setAutoFillBackground(True)
        self.lineEdit.setFrame(False)
        self.lineEdit.setDragEnabled(True)
        self.lineEdit.setReadOnly(True)
        self.lineEdit.setClearButtonEnabled(False)

        self.gridLayout_3.addWidget(self.lineEdit, 17, 5, 1, 3)

        self.save_pattern = QPushButton(self.tab)
        self.save_pattern.setObjectName(u"save_pattern")
        self.save_pattern.setCursor(QCursor(Qt.PointingHandCursor))

        self.gridLayout_3.addWidget(self.save_pattern, 4, 2, 1, 1)

        self.remove = QPushButton(self.tab)
        self.remove.setObjectName(u"remove")
        self.remove.setCursor(QCursor(Qt.PointingHandCursor))

        self.gridLayout_3.addWidget(self.remove, 3, 3, 1, 2)

        self.pushButton_5 = QPushButton(self.tab)
        self.pushButton_5.setObjectName(u"pushButton_5")
        self.pushButton_5.setCursor(QCursor(Qt.PointingHandCursor))

        self.gridLayout_3.addWidget(self.pushButton_5, 3, 5, 1, 1)

        self.Clear = QPushButton(self.tab)
        self.Clear.setObjectName(u"Clear")
        sizePolicy3.setHeightForWidth(self.Clear.sizePolicy().hasHeightForWidth())
        self.Clear.setSizePolicy(sizePolicy3)
        self.Clear.setCursor(QCursor(Qt.PointingHandCursor))

        self.gridLayout_3.addWidget(self.Clear, 4, 5, 1, 1)

        self.liste = QScrollArea(self.tab)
        self.liste.setObjectName(u"liste")
        sizePolicy.setHeightForWidth(self.liste.sizePolicy().hasHeightForWidth())
        self.liste.setSizePolicy(sizePolicy)
        self.liste.setMaximumSize(QSize(16777215, 16777215))
        self.liste.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self.liste.setWidgetResizable(True)
        self.liste.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignTop)
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setObjectName(u"scrollAreaWidgetContents")
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 289, 247))
        sizePolicy7 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy7.setHorizontalStretch(0)
        sizePolicy7.setVerticalStretch(0)
        sizePolicy7.setHeightForWidth(self.scrollAreaWidgetContents.sizePolicy().hasHeightForWidth())
        self.scrollAreaWidgetContents.setSizePolicy(sizePolicy7)
        self.gridLayout_2 = QGridLayout(self.scrollAreaWidgetContents)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.gridLayout_2.setSizeConstraint(QLayout.SetNoConstraint)
        self.label_4 = QLabel(self.scrollAreaWidgetContents)
        self.label_4.setObjectName(u"label_4")
        sizePolicy8 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Minimum)
        sizePolicy8.setHorizontalStretch(0)
        sizePolicy8.setVerticalStretch(0)
        sizePolicy8.setHeightForWidth(self.label_4.sizePolicy().hasHeightForWidth())
        self.label_4.setSizePolicy(sizePolicy8)
        self.label_4.setMinimumSize(QSize(90, 20))
        self.label_4.setMaximumSize(QSize(16777215, 16777215))
        self.label_4.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignTop)

        self.gridLayout_2.addWidget(self.label_4, 0, 3, 1, 1, Qt.AlignLeft|Qt.AlignTop)

        self.label_2 = QLabel(self.scrollAreaWidgetContents)
        self.label_2.setObjectName(u"label_2")
        sizePolicy8.setHeightForWidth(self.label_2.sizePolicy().hasHeightForWidth())
        self.label_2.setSizePolicy(sizePolicy8)
        self.label_2.setMinimumSize(QSize(100, 20))
        self.label_2.setMaximumSize(QSize(16777215, 16777215))
        self.label_2.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignTop)

        self.gridLayout_2.addWidget(self.label_2, 0, 2, 1, 1, Qt.AlignLeft|Qt.AlignTop)

        self.label_3 = QLabel(self.scrollAreaWidgetContents)
        self.label_3.setObjectName(u"label_3")
        sizePolicy8.setHeightForWidth(self.label_3.sizePolicy().hasHeightForWidth())
        self.label_3.setSizePolicy(sizePolicy8)
        self.label_3.setMinimumSize(QSize(0, 20))
        self.label_3.setMaximumSize(QSize(16777215, 16777215))
        self.label_3.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignTop)

        self.gridLayout_2.addWidget(self.label_3, 0, 4, 1, 1, Qt.AlignLeft|Qt.AlignTop)

        self.label_5 = QLabel(self.scrollAreaWidgetContents)
        self.label_5.setObjectName(u"label_5")
        sizePolicy9 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Minimum)
        sizePolicy9.setHorizontalStretch(0)
        sizePolicy9.setVerticalStretch(0)
        sizePolicy9.setHeightForWidth(self.label_5.sizePolicy().hasHeightForWidth())
        self.label_5.setSizePolicy(sizePolicy9)
        self.label_5.setMinimumSize(QSize(20, 20))
        self.label_5.setMaximumSize(QSize(20, 20))
        self.label_5.setAlignment(Qt.AlignLeading|Qt.AlignLeft|Qt.AlignTop)

        self.gridLayout_2.addWidget(self.label_5, 0, 1, 1, 1, Qt.AlignTop)

        self.liste.setWidget(self.scrollAreaWidgetContents)

        self.gridLayout_3.addWidget(self.liste, 5, 2, 11, 6)

        self.tabWidget.addTab(self.tab, "")
        self.tab_4 = QWidget()
        self.tab_4.setObjectName(u"tab_4")
        self.formLayout = QFormLayout(self.tab_4)
        self.formLayout.setObjectName(u"formLayout")
        self.pushButton_19 = QPushButton(self.tab_4)
        self.pushButton_19.setObjectName(u"pushButton_19")
        self.pushButton_19.setCursor(QCursor(Qt.PointingHandCursor))
        self.pushButton_19.setCheckable(True)

        self.formLayout.setWidget(0, QFormLayout.LabelRole, self.pushButton_19)

        self.label = QLabel(self.tab_4)
        self.label.setObjectName(u"label")

        self.formLayout.setWidget(1, QFormLayout.SpanningRole, self.label)

        self.label_12 = QLabel(self.tab_4)
        self.label_12.setObjectName(u"label_12")

        self.formLayout.setWidget(5, QFormLayout.SpanningRole, self.label_12)

        self.lineEdit_2 = QLineEdit(self.tab_4)
        self.lineEdit_2.setObjectName(u"lineEdit_2")
        self.lineEdit_2.setReadOnly(True)

        self.formLayout.setWidget(6, QFormLayout.LabelRole, self.lineEdit_2)

        self.comboBox = QComboBox(self.tab_4)
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.setObjectName(u"comboBox")
        self.comboBox.setCursor(QCursor(Qt.PointingHandCursor))

        self.formLayout.setWidget(2, QFormLayout.LabelRole, self.comboBox)

        self.label_7 = QLabel(self.tab_4)
        self.label_7.setObjectName(u"label_7")

        self.formLayout.setWidget(7, QFormLayout.LabelRole, self.label_7)

        self.spinBox = QSpinBox(self.tab_4)
        self.spinBox.setObjectName(u"spinBox")
        self.spinBox.setMaximum(12000)
        self.spinBox.setValue(10000)

        self.formLayout.setWidget(8, QFormLayout.LabelRole, self.spinBox)

        self.label_8 = QLabel(self.tab_4)
        self.label_8.setObjectName(u"label_8")

        self.formLayout.setWidget(9, QFormLayout.LabelRole, self.label_8)

        self.spinBox_2 = QSpinBox(self.tab_4)
        self.spinBox_2.setObjectName(u"spinBox_2")
        self.spinBox_2.setReadOnly(True)
        self.spinBox_2.setMinimum(-12000)
        self.spinBox_2.setMaximum(0)
        self.spinBox_2.setValue(-10000)

        self.formLayout.setWidget(10, QFormLayout.LabelRole, self.spinBox_2)

        self.label_10 = QLabel(self.tab_4)
        self.label_10.setObjectName(u"label_10")

        self.formLayout.setWidget(11, QFormLayout.LabelRole, self.label_10)

        self.spinBox_3 = QSpinBox(self.tab_4)
        self.spinBox_3.setObjectName(u"spinBox_3")
        self.spinBox_3.setValue(10)

        self.formLayout.setWidget(13, QFormLayout.LabelRole, self.spinBox_3)

        self.label_11 = QLabel(self.tab_4)
        self.label_11.setObjectName(u"label_11")

        self.formLayout.setWidget(15, QFormLayout.LabelRole, self.label_11)

        self.spinBox_4 = QSpinBox(self.tab_4)
        self.spinBox_4.setObjectName(u"spinBox_4")
        self.spinBox_4.setMaximum(50)
        self.spinBox_4.setValue(20)

        self.formLayout.setWidget(16, QFormLayout.LabelRole, self.spinBox_4)

        self.tabWidget.addTab(self.tab_4, "")
        self.tab_2 = QWidget()
        self.tab_2.setObjectName(u"tab_2")
        self.tab_2.setCursor(QCursor(Qt.ArrowCursor))
        self.gridLayout_4 = QGridLayout(self.tab_2)
        self.gridLayout_4.setObjectName(u"gridLayout_4")
        self.pushButton_6 = QPushButton(self.tab_2)
        self.pushButton_6.setObjectName(u"pushButton_6")
        sizePolicy10 = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)
        sizePolicy10.setHorizontalStretch(0)
        sizePolicy10.setVerticalStretch(0)
        sizePolicy10.setHeightForWidth(self.pushButton_6.sizePolicy().hasHeightForWidth())
        self.pushButton_6.setSizePolicy(sizePolicy10)
        self.pushButton_6.setCursor(QCursor(Qt.PointingHandCursor))

        self.gridLayout_4.addWidget(self.pushButton_6, 0, 1, 1, 1)

        self.pushButton_7 = QPushButton(self.tab_2)
        self.pushButton_7.setObjectName(u"pushButton_7")
        sizePolicy6.setHeightForWidth(self.pushButton_7.sizePolicy().hasHeightForWidth())
        self.pushButton_7.setSizePolicy(sizePolicy6)
        self.pushButton_7.setCursor(QCursor(Qt.PointingHandCursor))
        self.pushButton_7.setIcon(icon1)

        self.gridLayout_4.addWidget(self.pushButton_7, 1, 1, 1, 1, Qt.AlignLeft)

        self.scrollArea = QScrollArea(self.tab_2)
        self.scrollArea.setObjectName(u"scrollArea")
        sizePolicy11 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)
        sizePolicy11.setHorizontalStretch(0)
        sizePolicy11.setVerticalStretch(0)
        sizePolicy11.setHeightForWidth(self.scrollArea.sizePolicy().hasHeightForWidth())
        self.scrollArea.setSizePolicy(sizePolicy11)
        self.scrollArea.setWidgetResizable(True)
        self.scrollAreaWidgetContents_2 = QWidget()
        self.scrollAreaWidgetContents_2.setObjectName(u"scrollAreaWidgetContents_2")
        self.scrollAreaWidgetContents_2.setGeometry(QRect(0, 0, 694, 68))
        self.verticalLayout_2 = QVBoxLayout(self.scrollAreaWidgetContents_2)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.scrollArea.setWidget(self.scrollAreaWidgetContents_2)

        self.gridLayout_4.addWidget(self.scrollArea, 0, 2, 2, 1)

        self.Plotter_3 = PlotWidget(self.tab_2)
        self.Plotter_3.setObjectName(u"Plotter_3")
        sizePolicy2.setHeightForWidth(self.Plotter_3.sizePolicy().hasHeightForWidth())
        self.Plotter_3.setSizePolicy(sizePolicy2)

        self.gridLayout_4.addWidget(self.Plotter_3, 7, 1, 3, 2)

        self.tabWidget.addTab(self.tab_2, "")
        self.tab_3 = QWidget()
        self.tab_3.setObjectName(u"tab_3")
        self.tab_3.setCursor(QCursor(Qt.ArrowCursor))
        self.gridLayout_5 = QGridLayout(self.tab_3)
        self.gridLayout_5.setObjectName(u"gridLayout_5")
        self.pushButton_9 = QPushButton(self.tab_3)
        self.pushButton_9.setObjectName(u"pushButton_9")
        self.pushButton_9.setEnabled(False)
        sizePolicy10.setHeightForWidth(self.pushButton_9.sizePolicy().hasHeightForWidth())
        self.pushButton_9.setSizePolicy(sizePolicy10)
        self.pushButton_9.setCursor(QCursor(Qt.PointingHandCursor))
        self.pushButton_9.setIcon(icon1)

        self.gridLayout_5.addWidget(self.pushButton_9, 3, 0, 1, 1)

        self.pushButton_10 = QPushButton(self.tab_3)
        self.pushButton_10.setObjectName(u"pushButton_10")
        sizePolicy12 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy12.setHorizontalStretch(0)
        sizePolicy12.setVerticalStretch(0)
        sizePolicy12.setHeightForWidth(self.pushButton_10.sizePolicy().hasHeightForWidth())
        self.pushButton_10.setSizePolicy(sizePolicy12)
        self.pushButton_10.setCursor(QCursor(Qt.PointingHandCursor))

        self.gridLayout_5.addWidget(self.pushButton_10, 3, 1, 1, 1, Qt.AlignLeft)

        self.pushButton_8 = QPushButton(self.tab_3)
        self.pushButton_8.setObjectName(u"pushButton_8")
        sizePolicy4.setHeightForWidth(self.pushButton_8.sizePolicy().hasHeightForWidth())
        self.pushButton_8.setSizePolicy(sizePolicy4)
        self.pushButton_8.setCursor(QCursor(Qt.PointingHandCursor))
        self.pushButton_8.setIcon(icon1)

        self.gridLayout_5.addWidget(self.pushButton_8, 2, 0, 1, 2)

        self.Plotter_4 = PlotWidget(self.tab_3)
        self.Plotter_4.setObjectName(u"Plotter_4")
        sizePolicy2.setHeightForWidth(self.Plotter_4.sizePolicy().hasHeightForWidth())
        self.Plotter_4.setSizePolicy(sizePolicy2)

        self.gridLayout_5.addWidget(self.Plotter_4, 5, 0, 1, 4)

        self.textBrowser = QTextBrowser(self.tab_3)
        self.textBrowser.setObjectName(u"textBrowser")

        self.gridLayout_5.addWidget(self.textBrowser, 2, 2, 2, 1)

        self.tabWidget.addTab(self.tab_3, "")
        self.tab_9 = QWidget()
        self.tab_9.setObjectName(u"tab_9")
        self.gridLayout_10 = QGridLayout(self.tab_9)
        self.gridLayout_10.setObjectName(u"gridLayout_10")
        self.pushButton_20 = QPushButton(self.tab_9)
        self.pushButton_20.setObjectName(u"pushButton_20")
        self.pushButton_20.setIcon(icon1)

        self.gridLayout_10.addWidget(self.pushButton_20, 0, 0, 1, 2)

        self.textBrowser_2 = QTextBrowser(self.tab_9)
        self.textBrowser_2.setObjectName(u"textBrowser_2")

        self.gridLayout_10.addWidget(self.textBrowser_2, 0, 2, 2, 1)

        self.comboBox_3 = QComboBox(self.tab_9)
        self.comboBox_3.addItem("")
        self.comboBox_3.setObjectName(u"comboBox_3")

        self.gridLayout_10.addWidget(self.comboBox_3, 1, 0, 1, 1)

        self.pushButton_21 = QPushButton(self.tab_9)
        self.pushButton_21.setObjectName(u"pushButton_21")

        self.gridLayout_10.addWidget(self.pushButton_21, 1, 1, 1, 1)

        self.Plotter_5 = PlotWidget(self.tab_9)
        self.Plotter_5.setObjectName(u"Plotter_5")

        self.gridLayout_10.addWidget(self.Plotter_5, 2, 0, 1, 3)

        self.tabWidget.addTab(self.tab_9, "")

        self.gridLayout.addWidget(self.tabWidget, 0, 0, 1, 1)

        MainWindow.setCentralWidget(self.centralwidget)
#if QT_CONFIG(shortcut)
        self.label_6.setBuddy(self.checkBox)
#endif // QT_CONFIG(shortcut)

        self.retranslateUi(MainWindow)
        self.radioButton.toggled.connect(self.Add.setDisabled)
        self.radioButton.toggled.connect(self.remove.setDisabled)
        self.radioButton.toggled.connect(self.Clear.setDisabled)
        self.radioButton.toggled.connect(self.pushButton.setDisabled)
        self.pushButton.toggled.connect(self.radioButton.setDisabled)
        self.pushButton.toggled.connect(self.doubleSpinBox_2.setDisabled)
        self.pushButton.toggled.connect(self.pushButton_2.setDisabled)
        self.radioButton_2.toggled.connect(self.doubleSpinBox_2.setDisabled)
        self.radioButton_2.toggled.connect(self.pushButton_2.setDisabled)
        self.pushButton.toggled.connect(self.Clear.setDisabled)
        self.pushButton.toggled.connect(self.remove.setDisabled)
        self.pushButton.toggled.connect(self.Add.setDisabled)
        self.pushButton.toggled.connect(self.checkBox.setDisabled)
        self.pushButton.toggled.connect(self.lineEdit.setDisabled)
        self.pushButton.toggled.connect(self.pushButton_5.setDisabled)
        self.radioButton.toggled.connect(self.save_pattern.setDisabled)
        self.radioButton.toggled.connect(self.pattern.setDisabled)
        self.pushButton.toggled.connect(self.pattern.setDisabled)
        self.pushButton.toggled.connect(self.fold.setDisabled)
        self.pushButton_19.toggled.connect(self.comboBox.setDisabled)
        self.pushButton_19.toggled.connect(self.spinBox.setDisabled)
        self.pushButton_19.toggled.connect(self.spinBox_3.setDisabled)
        self.pushButton_19.toggled.connect(self.spinBox_4.setDisabled)
        self.pushButton_19.toggled.connect(self.spinBox_2.setDisabled)

        self.tabWidget.setCurrentIndex(0)
        self.comboBox.setCurrentIndex(1)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"CollaGui", None))
        self.label_9.setText(QCoreApplication.translate("MainWindow", u"Inversion:", None))
        self.pushButton.setText(QCoreApplication.translate("MainWindow", u"Start", None))
        self.label_6.setText(QCoreApplication.translate("MainWindow", u"&Open Valve:", None))
        self.radioButton_2.setText(QCoreApplication.translate("MainWindow", u"Pattern", None))
        self.Add.setText(QCoreApplication.translate("MainWindow", u"&Add Instruction", None))
        self.fold.setText("")
        self.doubleSpinBox_2.setSuffix(QCoreApplication.translate("MainWindow", u" mbar", None))
        self.radioButton.setText(QCoreApplication.translate("MainWindow", u"Manual", None))
        self.pushButton_4.setText("")
        self.checkBox.setText("")
        self.pushButton_2.setText(QCoreApplication.translate("MainWindow", u"Set", None))
        self.pattern.setText(QCoreApplication.translate("MainWindow", u"&Import", None))
        self.checkBox_2.setText("")
        self.save_pattern.setText(QCoreApplication.translate("MainWindow", u"&Save", None))
        self.remove.setText(QCoreApplication.translate("MainWindow", u"&Remove", None))
        self.pushButton_5.setText(QCoreApplication.translate("MainWindow", u"Clear Data", None))
        self.Clear.setText(QCoreApplication.translate("MainWindow", u"Clear", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"Pressure (mbar)", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"Instruction", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"Time (s)", None))
        self.label_5.setText("")
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), QCoreApplication.translate("MainWindow", u"Acquisition", None))
        self.pushButton_19.setText(QCoreApplication.translate("MainWindow", u"Connect", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"Fluigent Channel:", None))
        self.label_12.setText(QCoreApplication.translate("MainWindow", u"NIDAQ Device name:", None))
        self.lineEdit_2.setText(QCoreApplication.translate("MainWindow", u"Dev1", None))
        self.comboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"1", None))
        self.comboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"2", None))
        self.comboBox.setItemText(2, QCoreApplication.translate("MainWindow", u"3", None))
        self.comboBox.setItemText(3, QCoreApplication.translate("MainWindow", u"4", None))

        self.label_7.setText(QCoreApplication.translate("MainWindow", u"Max Voltage:", None))
        self.spinBox.setSuffix(QCoreApplication.translate("MainWindow", u"mV", None))
        self.label_8.setText(QCoreApplication.translate("MainWindow", u"Min Voltage:", None))
        self.spinBox_2.setSuffix(QCoreApplication.translate("MainWindow", u"mV", None))
        self.label_10.setText(QCoreApplication.translate("MainWindow", u"Number of samples", None))
        self.spinBox_3.setSuffix(QCoreApplication.translate("MainWindow", u"K", None))
        self.label_11.setText(QCoreApplication.translate("MainWindow", u"Integration time", None))
        self.spinBox_4.setSuffix(QCoreApplication.translate("MainWindow", u"ms", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_4), QCoreApplication.translate("MainWindow", u"NI-DAQ", None))
        self.pushButton_6.setText(QCoreApplication.translate("MainWindow", u"Clear", None))
        self.pushButton_7.setText(QCoreApplication.translate("MainWindow", u"MEAS", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), QCoreApplication.translate("MainWindow", u"Display", None))
        self.pushButton_9.setText(QCoreApplication.translate("MainWindow", u"Select Comsol", None))
        self.pushButton_10.setText(QCoreApplication.translate("MainWindow", u"Clear", None))
        self.pushButton_8.setText(QCoreApplication.translate("MainWindow", u"Select Measurement", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_3), QCoreApplication.translate("MainWindow", u"COMSOL", None))
        self.pushButton_20.setText(QCoreApplication.translate("MainWindow", u"Select Measurement", None))
        self.comboBox_3.setItemText(0, QCoreApplication.translate("MainWindow", u"1D", None))

        self.pushButton_21.setText(QCoreApplication.translate("MainWindow", u"Clear", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_9), QCoreApplication.translate("MainWindow", u"Model", None))
    # retranslateUi

